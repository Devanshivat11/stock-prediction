# Recurrent Neural Network(LSTM)  with Keras Framework
In this project using recurrent neural network,Google opening stock price for month January(2017) is predicted.
Last 5 year's data of Google stock price is used for analysis.

## About RNN
Classic RNNs have short memory, and were neither popular nor powerful for this exact reason. But a recent major improvement in Recurrent Neural Networks gave rise to the popularity of LSTMs (Long Short Term Memory RNNs) which has completely changed the playing field.


Predicted stock price for Google's trending Stock data
1. Successfully predicted Google stock price by using last 5 year's data of Google stock price.
2. Use of RNN(LSTM) was implemented alongside with Keras framework producing some good results.

Technology Used: Deep Learning , RNN , Machine Learning , LSTM

